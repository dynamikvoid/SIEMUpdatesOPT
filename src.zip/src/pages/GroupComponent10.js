import "./GroupComponent10.css";

const GroupComponent10 = () => {
  return (
    <div className="k-root">
      <div className="k3">$4K</div>
      <div className="k4">$2K</div>
      <div className="div23">$0</div>
    </div>
  );
};

export default GroupComponent10;
