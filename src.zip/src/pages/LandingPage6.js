import "./LandingPage6.css";

const LandingPage6 = () => {
  return (
    <div className="landing-page6">
      <div className="welcome-to1">{`Welcome to `}</div>
    </div>
  );
};

export default LandingPage6;
