import "./GroupComponent1.css";

const GroupComponent1 = () => {
  return (
    <div className="root">
      <div className="div14">0</div>
      <div className="div15">0.5</div>
      <div className="div16">1</div>
    </div>
  );
};

export default GroupComponent1;
