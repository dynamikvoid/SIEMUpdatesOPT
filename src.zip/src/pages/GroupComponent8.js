import "./GroupComponent8.css";

const GroupComponent8 = () => {
  return (
    <div className="ellipse-frame">
      <img className="group-child67" alt="" src="../ellipse-14.svg" />
      <img className="group-child68" alt="" src="../ellipse-24.svg" />
      <img className="group-child69" alt="" src="../ellipse-35.svg" />
    </div>
  );
};

export default GroupComponent8;
