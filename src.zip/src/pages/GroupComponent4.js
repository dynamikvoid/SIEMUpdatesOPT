import "./GroupComponent4.css";

const GroupComponent4 = () => {
  return (
    <div className="ellipse-root">
      <img className="group-child55" alt="" src="../ellipse-1.svg" />
      <img className="group-child56" alt="" src="../ellipse-2.svg" />
      <img className="group-child57" alt="" src="../ellipse-31.svg" />
    </div>
  );
};

export default GroupComponent4;
