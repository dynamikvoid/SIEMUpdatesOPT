import "./ExportToCodeErrorsDelete.css";

const ExportToCodeErrorsDelete = () => {
  return (
    <div className="export-to-code-errors-delete">
      <div className="navbar-needs-to-use-autolayou" />
      <div className="homefilled-needs-to-use-autol" />
      <div className="vector-needs-to-be-a-rasteriz" />
    </div>
  );
};

export default ExportToCodeErrorsDelete;
