import "./GroupComponent3.css";

const GroupComponent3 = () => {
  return (
    <div className="ellipse-parent">
      <img className="ellipse-icon" alt="" src="../ellipse-3.svg" />
    </div>
  );
};

export default GroupComponent3;
