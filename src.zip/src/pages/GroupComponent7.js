import "./GroupComponent7.css";

const GroupComponent7 = () => {
  return (
    <div className="ellipse-container">
      <img className="group-child64" alt="" src="../ellipse-13.svg" />
      <img className="group-child65" alt="" src="../ellipse-23.svg" />
      <img className="group-child66" alt="" src="../ellipse-34.svg" />
    </div>
  );
};

export default GroupComponent7;
