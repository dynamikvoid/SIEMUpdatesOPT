import "./GroupComponent6.css";

const GroupComponent6 = () => {
  return (
    <div className="ellipse-wrapper">
      <img className="group-child61" alt="" src="../ellipse-12.svg" />
      <img className="group-child62" alt="" src="../ellipse-22.svg" />
      <img className="group-child63" alt="" src="../ellipse-33.svg" />
    </div>
  );
};

export default GroupComponent6;
