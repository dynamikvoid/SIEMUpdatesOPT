import "./GroupComponent2.css";

const GroupComponent2 = () => {
  return (
    <div className="k-parent">
      <div className="k1">$4K</div>
      <div className="k2">$2K</div>
      <div className="div17">$0</div>
    </div>
  );
};

export default GroupComponent2;
