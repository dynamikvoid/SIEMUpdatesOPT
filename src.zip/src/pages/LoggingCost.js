import { useCallback } from "react";
import { useNavigate } from "react-router-dom";
import "./LoggingCost.css";

const LoggingCost = () => {
  const navigate = useNavigate();

  const onButtonContainerClick = useCallback(() => {
    navigate("/05-payment-sel");
  }, [navigate]);

  const onButtonContainer1Click = useCallback(() => {
    navigate("/04-exploration");
  }, [navigate]);

  const onButtonContainer2Click = useCallback(() => {
    navigate("/02-logging-cost");
  }, [navigate]);

  const onButtonContainer3Click = useCallback(() => {
    navigate("/01-alert-summary");
  }, [navigate]);

  const onButtonContainer4Click = useCallback(() => {
    navigate("/03-cost-analysis");
  }, [navigate]);
  
  const onButtonContainer5Click = useCallback(() => {
    navigate("/");
  }, [navigate]);

  return (
    <div className="logging-cost4">
      <div className="siem-ingestion-volume-by-parent">
        <div className="siem-ingestion-volume2">{`SIEM Ingestion Volume by `}</div>
        <div className="autocomplete8">
          <div className="wrapper20">
            <div className="field69">
              <div className="prefix69">
                <div className="icon189">
                  <img
                    className="starfilled-icon178"
                    alt=""
                    src="../starfilled118.svg"
                  />
                </div>
              </div>
              <div className="text-wrapper69">
                <div className="values20">
                  <div className="chip80">
                    <div className="container208">
                      <div className="avatar80">
                        <div className="avatar81">
                          <div className="op40">OP</div>
                        </div>
                      </div>
                      <div className="typography166">
                        <div className="chip81">Chip</div>
                      </div>
                      <img
                        className="cancelfilled-icon40"
                        alt=""
                        src="../cancelfilled40.svg"
                      />
                    </div>
                  </div>
                  <div className="chip80">
                    <div className="container208">
                      <div className="avatar80">
                        <div className="avatar81">
                          <div className="op40">OP</div>
                        </div>
                      </div>
                      <div className="typography166">
                        <div className="chip81">Chip</div>
                      </div>
                      <img
                        className="cancelfilled-icon40"
                        alt=""
                        src="../cancelfilled41.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className="value139">All</div>
              </div>
              <div className="clear20">
                <div className="iconbutton94">
                  <img className="starfilled-icon178" alt="" />
                </div>
              </div>
              <div className="suffix69">
                <div className="iconbutton95">
                  <img
                    className="starfilled-icon178"
                    alt=""
                    src="../arrowdropdownfilled22.svg"
                  />
                </div>
              </div>
            </div>
            <div className="alignment20">
              <div className="basicmenu20">
                <div className="menuitem60">
                  <div className="container210">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">Azure</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
                <div className="menuitem60">
                  <div className="container210">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">OpsManager</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
                <div className="menuitem60">
                  <div className="container214">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">Linux</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="helper69">
            <div className="text184">Descriptive text</div>
          </div>
          <div className="label70">
            <div className="label-background69">
              <div className="cutborder69" />
              <div className="text185">Source System</div>
            </div>
          </div>
        </div>
        <div className="autocomplete9">
          <div className="wrapper20">
            <div className="field69">
              <div className="prefix69">
                <div className="icon189">
                  <img
                    className="starfilled-icon178"
                    alt=""
                    src="../starfilled119.svg"
                  />
                </div>
              </div>
              <div className="text-wrapper69">
                <div className="values20">
                  <div className="chip80">
                    <div className="container208">
                      <div className="avatar80">
                        <div className="avatar81">
                          <div className="op40">OP</div>
                        </div>
                      </div>
                      <div className="typography166">
                        <div className="chip81">Chip</div>
                      </div>
                      <img
                        className="cancelfilled-icon40"
                        alt=""
                        src="../cancelfilled42.svg"
                      />
                    </div>
                  </div>
                  <div className="chip80">
                    <div className="container208">
                      <div className="avatar80">
                        <div className="avatar81">
                          <div className="op40">OP</div>
                        </div>
                      </div>
                      <div className="typography166">
                        <div className="chip81">Chip</div>
                      </div>
                      <img
                        className="cancelfilled-icon40"
                        alt=""
                        src="../cancelfilled43.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className="value139">All</div>
              </div>
              <div className="clear20">
                <div className="iconbutton94">
                  <img className="starfilled-icon178" alt="" />
                </div>
              </div>
              <div className="suffix69">
                <div className="iconbutton95">
                  <img
                    className="starfilled-icon178"
                    alt=""
                    src="../arrowdropdownfilled23.svg"
                  />
                </div>
              </div>
            </div>
            <div className="alignment20">
              <div className="basicmenu20">
                <div className="menuitem60">
                  <div className="container210">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">Table 1....</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
                <div className="menuitem60">
                  <div className="container210">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">Table ...n</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
                <div className="menuitem65">
                  <div className="container214">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">Field Value</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="helper69">
            <div className="text184">Descriptive text</div>
          </div>
          <div className="label70">
            <div className="label-background69">
              <div className="cutborder69" />
              <div className="text185">Table</div>
            </div>
          </div>
        </div>
        <div className="overall-siem-ingestion-volume-parent">
          <div className="overall-siem-ingestion3">
            Overall SIEM Ingestion Volume
          </div>
          <div className="group-child70" />
          <div className="nov-12-20222">Nov 12, 2022</div>
          <div className="dec-12-20222">Dec 12, 2022</div>
          <div className="jan-12-20232">Jan 12, 2023</div>
          <div className="feb-12-2023">Feb 12, 2023</div>
          <img className="group-child71" alt="" src="../line-12.svg" />
          <img className="group-child72" alt="" src="../polygon-12.svg" />
          <div className="gb10">11.2GB</div>
          <div className="gb11">16.4GB</div>
          <div className="gb12">16.9GB</div>
          <div className="autocomplete-parent">
            <div className="autocomplete10">
              <div className="wrapper20">
                <div className="field69">
                  <div className="prefix69">
                    <div className="icon189">
                      <img
                        className="starfilled-icon178"
                        alt=""
                        src="../starfilled120.svg"
                      />
                    </div>
                  </div>
                  <div className="text-wrapper69">
                    <div className="values20">
                      <div className="chip80">
                        <div className="container208">
                          <div className="avatar80">
                            <div className="avatar81">
                              <div className="op40">OP</div>
                            </div>
                          </div>
                          <div className="typography166">
                            <div className="chip81">Chip</div>
                          </div>
                          <img
                            className="cancelfilled-icon40"
                            alt=""
                            src="../cancelfilled44.svg"
                          />
                        </div>
                      </div>
                      <div className="chip90">
                        <div className="container208">
                          <div className="avatar80">
                            <div className="avatar81">
                              <div className="op40">OP</div>
                            </div>
                          </div>
                          <div className="typography166">
                            <div className="chip81">Chip</div>
                          </div>
                          <img className="cancelfilled-icon40" alt="" />
                        </div>
                      </div>
                    </div>
                    <div className="value139">Days</div>
                  </div>
                  <div className="clear20">
                    <div className="iconbutton94">
                      <img className="starfilled-icon178" alt="" />
                    </div>
                  </div>
                  <div className="suffix69">
                    <div className="iconbutton95">
                      <img
                        className="starfilled-icon178"
                        alt=""
                        src="../arrowdropdownfilled24.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className="alignment20">
                  <div className="basicmenu20">
                    <div className="menuitem60">
                      <div className="container226">
                        <div className="menuitembasicslot66">
                          <div className="icon190">
                            <div className="icon191">
                              <img className="starfilled-icon178" alt="" />
                            </div>
                          </div>
                          <div className="container211">
                            <div className="value140">Days</div>
                            <div className="right-content60">
                              <div className="typography168">⌘X</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="divider84">
                        <div className="rectangle78" />
                      </div>
                    </div>
                    <div className="menuitem60">
                      <div className="container226">
                        <div className="menuitembasicslot66">
                          <div className="icon190">
                            <div className="icon191">
                              <img className="starfilled-icon178" alt="" />
                            </div>
                          </div>
                          <div className="container211">
                            <div className="value140">Months</div>
                            <div className="right-content60">
                              <div className="typography168">⌘X</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="divider84">
                        <div className="rectangle78" />
                      </div>
                    </div>
                    <div className="menuitem60">
                      <div className="container214">
                        <div className="menuitembasicslot66">
                          <div className="icon190">
                            <div className="icon191">
                              <img className="starfilled-icon178" alt="" />
                            </div>
                          </div>
                          <div className="container211">
                            <div className="value140">Years</div>
                            <div className="right-content60">
                              <div className="typography168">⌘X</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="divider84">
                        <div className="rectangle78" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="helper71">
                <div className="text184">Descriptive text</div>
              </div>
              <div className="label72">
                <div className="label-background69">
                  <div className="cutborder69" />
                  <div className="text189">Source</div>
                </div>
              </div>
            </div>
            <div className="text-field49">
              <div className="field72">
                <div className="prefix72">
                  <div className="icon189">
                    <img
                      className="starfilled-icon178"
                      alt=""
                      src="../starfilled121.svg"
                    />
                  </div>
                </div>
                <div className="text-wrapper72">
                  <div className="value151">30</div>
                </div>
                <div className="suffix72">
                  <div className="iconbutton100">
                    <img
                      className="starfilled-icon178"
                      alt=""
                      src="../starfilled122.svg"
                    />
                  </div>
                </div>
              </div>
              <div className="helper72">
                <div className="text190">Blue</div>
              </div>
              <div className="label72">
                <div className="label-background69">
                  <div className="cutborder69" />
                  <div className="text189">Date Range</div>
                </div>
              </div>
            </div>
            <div className="forecast-the-next">Forecast the next</div>
            <div className="ellipse-group">
              <img className="group-child73" alt="" src="../ellipse-132.svg" />
              <div className="div18">?</div>
            </div>
          </div>
        </div>
        <div className="group-parent3">
          <img className="group-child74" alt="" src="../group-33.svg" />
          <div className="gbday">GB/Day</div>
        </div>
        <div className="gb13">35GB</div>
        <div className="gb14">0GB</div>
        <div className="text-field50">
          <div className="field72">
            <div className="prefix72">
              <div className="icon189">
                <img
                  className="starfilled-icon178"
                  alt=""
                  src="../starfilled123.svg"
                />
              </div>
            </div>
            <div className="text-wrapper72">
              <div className="value151">90</div>
            </div>
            <div className="suffix72">
              <div className="iconbutton100">
                <img
                  className="starfilled-icon178"
                  alt=""
                  src="../starfilled124.svg"
                />
              </div>
            </div>
          </div>
          <div className="helper72">
            <div className="text190">Blue</div>
          </div>
          <div className="label72">
            <div className="label-background69">
              <div className="cutborder69" />
              <div className="text189">Date Range</div>
            </div>
          </div>
        </div>
        <div className="rectangle-parent39">
          <div className="instance-child63" />
          <div className="vector-parent">
            <img className="rectangle-icon" alt="" src="../rectangle-20.svg" />
            <img className="group-child75" alt="" src="../rectangle-21.svg" />
            <img className="group-child76" alt="" src="../rectangle-22.svg" />
            <b className="azure2">Azure</b>
            <b className="opsmanager">OpsManager</b>
            <b className="linux1">Linux</b>
          </div>
          <div className="jan-12-20233">Jan 12, 2023</div>
          <div className="sep-12-2022">Sep 12, 2022</div>
          <div className="jun-12-2023">Jun 12, 2023</div>
          <div className="gb15">0 GB</div>
          <div className="gb16">35 GB</div>
          <div className="switch-container">
            <div className="switch2">
              <div className="value140">Detailed View</div>
              <div className="switch3">
                <div className="slide2">
                  <div className="slide3" />
                </div>
                <div className="knob1">
                  <img className="knob-icon1" alt="" src="../knob1.svg" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="autocomplete11">
          <div className="wrapper20">
            <div className="field69">
              <div className="prefix69">
                <div className="icon189">
                  <img
                    className="starfilled-icon178"
                    alt=""
                    src="../starfilled125.svg"
                  />
                </div>
              </div>
              <div className="text-wrapper69">
                <div className="values20">
                  <div className="chip80">
                    <div className="container208">
                      <div className="avatar80">
                        <div className="avatar81">
                          <div className="op40">OP</div>
                        </div>
                      </div>
                      <div className="typography166">
                        <div className="chip81">Chip</div>
                      </div>
                      <img
                        className="cancelfilled-icon40"
                        alt=""
                        src="../cancelfilled45.svg"
                      />
                    </div>
                  </div>
                  <div className="chip80">
                    <div className="container208">
                      <div className="avatar80">
                        <div className="avatar81">
                          <div className="op40">OP</div>
                        </div>
                      </div>
                      <div className="typography166">
                        <div className="chip81">Chip</div>
                      </div>
                      <img
                        className="cancelfilled-icon40"
                        alt=""
                        src="../cancelfilled46.svg"
                      />
                    </div>
                  </div>
                </div>
                <div className="value139">Source System</div>
              </div>
              <div className="clear20">
                <div className="iconbutton94">
                  <img className="starfilled-icon178" alt="" />
                </div>
              </div>
              <div className="suffix69">
                <div className="iconbutton95">
                  <img
                    className="starfilled-icon178"
                    alt=""
                    src="../arrowdropdownfilled25.svg"
                  />
                </div>
              </div>
            </div>
            <div className="alignment20">
              <div className="basicmenu20">
                <div className="menuitem60">
                  <div className="container210">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">Table</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
                <div className="menuitem60">
                  <div className="container210">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">Source System</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
                <div className="menuitem65">
                  <div className="container214">
                    <div className="menuitembasicslot60">
                      <div className="icon190">
                        <div className="icon191">
                          <img className="starfilled-icon178" alt="" />
                        </div>
                      </div>
                      <div className="container211">
                        <div className="value140">Field Value</div>
                        <div className="right-content60">
                          <div className="typography168">⌘X</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="divider78">
                    <div className="rectangle78" />
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="helper69">
            <div className="text184">Descriptive text</div>
          </div>
          <div className="label72">
            <div className="label-background69">
              <div className="cutborder69" />
              <div className="text189">Source</div>
            </div>
          </div>
        </div>
      </div>
      <div className="logging-cost-inner">
        <div className="autocomplete-group">
          <div className="autocomplete-group">
            <div className="autocomplete-group">
              <div className="autocomplete10">
                <div className="wrapper20">
                  <div className="field69">
                    <div className="prefix69">
                      <div className="icon189">
                        <img
                          className="starfilled-icon178"
                          alt=""
                          src="../starfilled126.svg"
                        />
                      </div>
                    </div>
                    <div className="text-wrapper69">
                      <div className="values20">
                        <div className="chip80">
                          <div className="container208">
                            <div className="avatar80">
                              <div className="avatar81">
                                <div className="op40">OP</div>
                              </div>
                            </div>
                            <div className="typography166">
                              <div className="chip81">Chip</div>
                            </div>
                            <img
                              className="cancelfilled-icon40"
                              alt=""
                              src="../cancelfilled47.svg"
                            />
                          </div>
                        </div>
                        <div className="chip80">
                          <div className="container208">
                            <div className="avatar80">
                              <div className="avatar81">
                                <div className="op40">OP</div>
                              </div>
                            </div>
                            <div className="typography166">
                              <div className="chip81">Chip</div>
                            </div>
                            <img
                              className="cancelfilled-icon40"
                              alt=""
                              src="../cancelfilled48.svg"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="value139">Days</div>
                    </div>
                    <div className="clear20">
                      <div className="iconbutton94">
                        <img className="starfilled-icon178" alt="" />
                      </div>
                    </div>
                    <div className="suffix69">
                      <div className="iconbutton95">
                        <img
                          className="starfilled-icon178"
                          alt=""
                          src="../arrowdropdownfilled26.svg"
                        />
                      </div>
                    </div>
                  </div>
                  <div className="alignment20">
                    <div className="basicmenu20">
                      <div className="menuitem60">
                        <div className="container226">
                          <div className="menuitembasicslot66">
                            <div className="icon190">
                              <div className="icon191">
                                <img className="starfilled-icon178" alt="" />
                              </div>
                            </div>
                            <div className="container211">
                              <div className="value140">Days</div>
                              <div className="right-content60">
                                <div className="typography168">⌘X</div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="divider84">
                          <div className="rectangle78" />
                        </div>
                      </div>
                      <div className="menuitem60">
                        <div className="container226">
                          <div className="menuitembasicslot66">
                            <div className="icon190">
                              <div className="icon191">
                                <img className="starfilled-icon178" alt="" />
                              </div>
                            </div>
                            <div className="container211">
                              <div className="value140">Months</div>
                              <div className="right-content60">
                                <div className="typography168">⌘X</div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="divider84">
                          <div className="rectangle78" />
                        </div>
                      </div>
                      <div className="menuitem60">
                        <div className="container214">
                          <div className="menuitembasicslot66">
                            <div className="icon190">
                              <div className="icon191">
                                <img className="starfilled-icon178" alt="" />
                              </div>
                            </div>
                            <div className="container211">
                              <div className="value140">Years</div>
                              <div className="right-content60">
                                <div className="typography168">⌘X</div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="divider84">
                          <div className="rectangle78" />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="helper71">
                  <div className="text184">Descriptive text</div>
                </div>
                <div className="label72">
                  <div className="label-background69">
                    <div className="cutborder69" />
                    <div className="text189">Source</div>
                  </div>
                </div>
              </div>
              <div className="group-child77" />
              <div className="forecast-the-next">{`See the last `}</div>
              <img className="group-child78" alt="" src="../ellipse-132.svg" />
              <div className="div19">?</div>
            </div>
          </div>
        </div>
      </div>
      <img
        className="downloadfilled-icon3"
        alt=""
        src="../downloadfilled2.svg"
      />
      <div className="navbar7">
        <div className="navbar-child5" />
        <div className="button46" onClick={onButtonContainerClick}>
          <div className="container248">
            <img className="prefix-icon46" alt="" src="../prefix46.svg" />
            <div className="text198">Payment Sel.</div>
            <img className="prefix-icon46" alt="" src="../suffix8.svg" />
          </div>
        </div>
        <div className="button47" onClick={onButtonContainer1Click}>
          <div className="container248">
            <img className="prefix-icon46" alt="" src="../prefix47.svg" />
            <div className="text198">Exploration</div>
            <img className="prefix-icon46" alt="" src="../suffix8.svg" />
          </div>
        </div>
        <div className="button48" onClick={onButtonContainer2Click}>
          <div className="container248">
            <img className="prefix-icon46" alt="" src="../prefix48.svg" />
            <div className="text200">Ingestion Volume</div>
            <img className="prefix-icon46" alt="" src="../suffix48.svg" />
          </div>
        </div>
        <div className="button49" onClick={onButtonContainer3Click}>
          <div className="container248">
            <img className="prefix-icon46" alt="" src="../prefix49.svg" />
            <div className="text198">Alert Summary</div>
            <img className="prefix-icon46" alt="" src="../suffix8.svg" />
          </div>
        </div>
        <div className="button50" onClick={onButtonContainer4Click}>
          <div className="container248">
            <img className="prefix-icon46" alt="" src="../prefix50.svg" />
            <div className="text198">Cost Analysis</div>
            <img className="prefix-icon46" alt="" src="../suffix8.svg" />
          </div>
        </div>
        <div className="iconbutton106">
          <img className="homefilled-icon" alt="" src="../homefilled.svg" />
        </div>
      </div>
    </div>
  );
};

export default LoggingCost;
