import "./GroupComponent9.css";

const GroupComponent9 = () => {
  return (
    <div className="top">
      <div className="div20">0</div>
      <div className="div21">0.5</div>
      <div className="div22">1</div>
    </div>
  );
};

export default GroupComponent9;
