import "./GroupComponent5.css";

const GroupComponent5 = () => {
  return (
    <div className="ellipse-top">
      <img className="group-child58" alt="" src="../ellipse-11.svg" />
      <img className="group-child59" alt="" src="../ellipse-21.svg" />
      <img className="group-child60" alt="" src="../ellipse-32.svg" />
    </div>
  );
};

export default GroupComponent5;
