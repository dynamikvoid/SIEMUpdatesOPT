import React from 'react'

const GetData = () => {
  return (
    <div style={{ padding:'10px' }}>
      <span className="annualized-recovery-value2">
        Annualized Recovery Value
      </span>  
      <span className="per-rule">{` per Rule `}</span>
    </div>
  )
}

export default GetData
